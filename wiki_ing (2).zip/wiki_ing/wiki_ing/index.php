<?php
header('Content-Type: text/html; charset=UTF-8');
include('conexion.php');
if ($conn) $conn->set_charset("utf8");

// Definición de secciones
$secciones = [
  'nivelesprueba' => 'NIVELES DE PRUEBA',
  'pruebascambio' => 'PRUEBAS RELACIONADAS CON EL CAMBIO',
  'pruebasintegracion' => 'PRUEBAS DE INTEGRACIÓN',
  'pruebasnofuncionales' => 'PRUEBAS NO FUNCIONALES',
  'pruebasrendimiento' => 'PRUEBAS DE RENDIMIENTO',
  'pruebasusabilidad' => 'PRUEBAS DE USABILIDAD',
  'tiposprueba' => 'TIPOS DE PRUEBA'
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WikiTec Neo | Glosario de Pruebas de Software</title>
  <link rel="stylesheet" href="estilos.css">
  <script src="https://kit.fontawesome.com/a2b5a0c1e4.js" crossorigin="anonymous"></script>
</head>
<body>


<!-- Barra de navegación -->
<nav class="navbar">
    <div class="logo">🧠 WikiTec</div>
    <ul class="nav-links">
        <li><a href="#inicio">Inicio</a></li>
        <li><a href="#glosario">Glosario</a></li>
        <li><a href="#sobre">Acerca</a></li>
    </ul>
    <button id="modo-btn">🌙</button>
</nav>

<!-- HERO -->
<header id="inicio" class="hero">
  <div class="hero-content">
    <h1>Domina las <span>Pruebas de Software</span></h1>
    <p>Aprende los fundamentos, niveles y estrategias de testing que garantizan 
       la calidad y confiabilidad del software moderno.</p>
    <a href="#glosario" class="btn-hero">🚀 Comenzar Aprendizaje</a>
  </div>
</header>

<!-- GLOSARIO -->
<section id="glosario" class="glosario">
  <h2>📚 Glosario de Conceptos</h2>
  <div class="cards-container">
    <?php foreach ($secciones as $tabla => $titulo): ?>
      <div class="glosario-card">
        <h3><?php echo $titulo; ?></h3>
        <div class="conceptos">
          <?php
          $sql = "SELECT * FROM $tabla ORDER BY id ASC";
          $result = $conn->query($sql);
          if ($result && $result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
          ?>
              <article class="concepto-item">
                <h4><?php echo htmlspecialchars($row['concepto']); ?></h4>
                <p><?php echo htmlspecialchars($row['definicion']); ?></p>
              </article>
          <?php
            endwhile;
          else:
            echo "<p class='vacio'>No hay registros en esta categoría.</p>";
          endif;
          ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- SECCIÓN SOBRE -->
<section id="sobre" class="sobre">
  <div class="sobre-contenido">
    <h2> Sobre este Proyecto</h2>
    <p>
      <strong>WikiTec</strong> es una wiki interactiva creada para la materia <strong>Ingeniería de Software III</strong> de la 
      <em>Universidad Tecnológica de Panamá</em>. Está construida con PHP, MySQL y Docker, ofreciendo un entorno modular
      y escalable para mostrar información técnica sobre pruebas de software.
    </p>
    <p>
      Cada sección del glosario presenta información estructurada de manera visual, fomentando el aprendizaje autodidacta
      y la exploración de los diferentes tipos de pruebas.
    </p>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <p>© <?php echo date("Y"); ?> WikiTec | Universidad Tecnológica de Panamá</p>
</footer>

<!-- SCRIPT -->
<script>
// ======== Modo Oscuro Dinámico ========
const btnModo = document.getElementById("modo-btn");
btnModo.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
  btnModo.textContent = document.body.classList.contains("dark-mode") ? "☀️" : "🌙";
});

// SCROLL SUAVE
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener("click",e=>{
    e.preventDefault();
    document.querySelector(a.getAttribute("href")).scrollIntoView({behavior:"smooth"});
  });
});

// NAVBAR SCROLL EFECTO
window.addEventListener("scroll", () => {
  const nav = document.querySelector(".navbar");
  if (window.scrollY > 60) {
    nav.classList.add("scrolled");
  } else {
    nav.classList.remove("scrolled");
  }
});
</script>
</body>
</html>
