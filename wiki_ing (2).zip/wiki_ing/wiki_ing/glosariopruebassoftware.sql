-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-10-2025 a las 05:48:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `glosariopruebassoftware`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nivelesprueba`
--

CREATE TABLE `nivelesprueba` (
  `id` int(11) NOT NULL,
  `concepto` varchar(100) NOT NULL,
  `definicion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `nivelesprueba`
--

INSERT INTO `nivelesprueba` (`id`, `concepto`, `definicion`) VALUES
(1, 'Pruebas Unitarias', 'Definición pendiente'),
(2, 'Pruebas de Integración', 'Son un tipo de prueba de software que se encarga de verificar cómo los diferentes módulos o componentes de un sistema interactúan entre sí. A diferencia de las pruebas unitarias, su objetivo no es solo asegurar que cada módulo funcione individualmente, sino que trabajen de forma coherente y correcta cuando se combinan, identificando errores en las interfaces y en la comunicación entre ellos para garantizar que el sistema cumpla con sus requisitos.'),
(3, 'Pruebas de Sistemas', 'Son una fase del aseguramiento de la calidad del software en la que se evalúa el sistema completo ya integrado, para comprobar que cumple con los requisitos especificados. Su objetivo es analizar el comportamiento general del sistema y cómo interactúa con otros sistemas. Durante estas pruebas se evalúan funcionalidades, rendimiento, seguridad, usabilidad y otros aspectos críticos del sistema.'),
(4, 'Pruebas de Aceptación', 'Son la fase final del proceso de pruebas, donde se verifica que el sistema cumple con los requisitos del negocio y las expectativas del usuario. Por lo general, estas pruebas las realizan los usuarios finales o clientes. Estas pruebas se realizan en un entorno controlado que simula las condiciones de producción y pueden incluir pruebas alfa, beta y pruebas de usuario (UAT).');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pruebascambio`
--

CREATE TABLE `pruebascambio` (
  `id` int(11) NOT NULL,
  `concepto` varchar(100) NOT NULL,
  `definicion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pruebascambio`
--

INSERT INTO `pruebascambio` (`id`, `concepto`, `definicion`) VALUES
(1, 'Prueba de Regresión', 'Es un tipo de prueba de software que se realiza cada vez que se introduce un cambio en el sistema. Su objetivo principal es verificar que el cambio no haya generado defectos en las partes que ya funcionaban correctamente. Se reejecutan casos de prueba previamente diseñados sobre las áreas del software que podrían verse afectadas por el cambio.'),
(2, 'Prueba de Confirmación', 'Son un tipo de prueba de regresión enfocada en verificar si un defecto previamente identificado y corregido ha sido realmente solucionado. Después de una corrección, se vuelven a ejecutar todos los casos de prueba que fallaron debido a ese defecto original para asegurarse de que ahora pasan, validando así la efectividad del cambio en el software.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pruebasintegracion`
--

CREATE TABLE `pruebasintegracion` (
  `id` int(11) NOT NULL,
  `concepto` varchar(100) NOT NULL,
  `definicion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pruebasintegracion`
--

INSERT INTO `pruebasintegracion` (`id`, `concepto`, `definicion`) VALUES
(1, 'Prueba de Caja Negra', 'Implica probar un sistema sin conocimiento previo de su funcionamiento interno. Un evaluador proporciona una entrada y observa la salida generada por el sistema bajo prueba. Esto permite identificar cómo responde el sistema a las acciones esperadas e inesperadas del usuario, su tiempo de respuesta y los problemas de usabilidad y confiabilidad. Durante el proceso, una prueba de caja negra evalúa todos los subsistemas relevantes, incluyendo la interfaz de usuario/experiencia de usuario (UI/UX), el servidor web o de aplicaciones, la base de datos, las dependencias y los sistemas integrados.'),
(2, 'Prueba de Caja Blanca', 'Es una técnica de prueba de software que consiste en evaluar el código interno, la estructura, los flujos lógicos y las condiciones de un programa para verificar que funciona correctamente. Se enfoca en la estructura interna del software y permite encontrar errores de lógica, condiciones no utilizadas, bucles infinitos o caminos no alcanzables.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pruebasnofuncionales`
--

CREATE TABLE `pruebasnofuncionales` (
  `id` int(11) NOT NULL,
  `concepto` varchar(100) NOT NULL,
  `definicion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pruebasnofuncionales`
--

INSERT INTO `pruebasnofuncionales` (`id`, `concepto`, `definicion`) VALUES
(1, 'Prueba de Rendimiento', 'Son métodos de prueba de software que se utiliza para evaluar la funcionalidad de un producto bajo determinadas condiciones de uso como: cargas de trabajo, condición de red y volumen de datos esperados, esto con el objetivo de buscar resultados de rapidez, estabilidad, escalabilidad y capacidad de respuesta.'),
(2, 'Prueba de Usabilidad', 'Es un tipo de prueba de software que se centra en la experiencia del usuario. Evalúa qué tan fácil, intuitivo y eficiente resulta para una persona real utilizar una aplicación o sistema. Busca responder preguntas como: ¿Los usuarios entienden cómo usar la interfaz? ¿Pueden completar las tareas sin dificultad? ¿Cometen errores frecuentes al interactuar? ¿El diseño es agradable y accesible?'),
(3, 'Prueba de Seguridad', 'Es un proceso de evaluación diseñado para verificar si un sistema, aplicación o red es seguro frente a amenazas internas y externas. Busca garantizar que los datos y servicios estén protegidos contra accesos no autorizados, alteraciones o pérdidas.'),
(4, 'Prueba de Recuperación', 'Es un tipo de prueba de software no funcional que evalúa la capacidad de un sistema para recuperarse de fallos, interrupciones o desastres y volver a funcionar normalmente. Su objetivo principal es verificar que el sistema puede restaurar sus operaciones, datos y funcionalidades después de experimentar una falla inesperada.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pruebasrendimiento`
--

CREATE TABLE `pruebasrendimiento` (
  `id` int(11) NOT NULL,
  `concepto` varchar(100) NOT NULL,
  `definicion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pruebasrendimiento`
--

INSERT INTO `pruebasrendimiento` (`id`, `concepto`, `definicion`) VALUES
(1, 'Prueba de Carga', 'Es un tipo de prueba no funcional que consiste en evaluar el comportamiento de un sistema, aplicación o servicio bajo una cantidad específica de usuarios, transacciones o peticiones simultáneas. Su propósito es comprobar si el sistema puede manejar la carga esperada de trabajo en condiciones normales y sostenidas de uso.'),
(2, 'Prueba de Estrés', 'Es un tipo de prueba no funcional que se realiza para evaluar el comportamiento de un sistema, aplicación o componente cuando se expone a condiciones extremas de carga, más allá de los niveles normales de operación. Su objetivo principal es identificar los límites de capacidad, posibles fallos, cuellos de botella y cómo se recupera el sistema después de que la carga vuelva a niveles normales.'),
(3, 'Pruebas de Escalabilidad', 'Son un tipo de prueba de rendimiento dentro de la ingeniería de software que evalúa la capacidad de un sistema para mantener su estabilidad y eficiencia cuando aumenta la carga de trabajo. Permiten conocer hasta qué punto una aplicación o infraestructura puede crecer en número de usuarios, transacciones o volumen de datos sin perder calidad en el servicio.'),
(4, 'Prueba de Concurrencia', 'Es un tipo de prueba de software que se utiliza para verificar el comportamiento de una aplicación cuando múltiples usuarios o procesos acceden y ejecutan operaciones al mismo tiempo. Su objetivo es identificar fallos como condiciones de carrera, bloqueos (deadlocks), corrupción de datos o pérdida de rendimiento que ocurren en escenarios simultáneos.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pruebasusabilidad`
--

CREATE TABLE `pruebasusabilidad` (
  `id` int(11) NOT NULL,
  `concepto` varchar(100) NOT NULL,
  `definicion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pruebasusabilidad`
--

INSERT INTO `pruebasusabilidad` (`id`, `concepto`, `definicion`) VALUES
(1, 'Prueba de Experiencia de Usuario', 'Es el proceso de evaluar diferentes aspectos de la usabilidad del software para determinar la mejor manera de que un sitio web o aplicativo y sus elementos interactúen con su audiencia. Las pruebas de usabilidad se encargan de evaluar un producto mediante la interacción directa con los usuarios.'),
(2, 'Prueba de Accesibilidad', 'Es una revisión o evaluación que se hace a un software, aplicación o página web para comprobar que cualquier persona pueda usarlo, incluso quienes tienen alguna discapacidad (por ejemplo, alguien que no puede ver bien, no escucha, o no puede usar un mouse).\r\n1. Revisión automática (con programas)\r\n•	Se usan herramientas (como un \"escáner\") que analizan la aplicación.\r\n•	Estas detectan problemas comunes, por ejemplo:\r\no	Texto demasiado pequeño o poco legible.\r\no	Colores que no tienen suficiente contraste (ejemplo: letras grises sobre fondo blanco).\r\no	Imágenes sin descripción (una persona ciega no sabría qué muestra la foto).\r\n•	El programa da un reporte con los errores para corregirlos.\r\nEjemplo:\r\nUna página tiene una imagen de un médico, pero no tiene descripción. El programa dice: “Falta texto alternativo en la imagen”.\r\n2. Revisión manual (con personas)\r\n•	Aquí entra el factor humano, porque los programas no detectan todo.\r\n•	Un tester o evaluador prueba la aplicación como si tuviera una discapacidad, por ejemplo:\r\no	Sin mouse: Solo con teclado, usando la tecla TAB para moverse entre botones y campos. Si no puede llegar a un botón, hay un problema.\r\no	Con lector de pantalla: Una voz que “lee” lo que aparece en la pantalla. Si el botón dice solo “clic aquí” sin contexto, la persona no entiende para qué sirve.\r\no	Con ampliación de pantalla: Revisar si el diseño sigue funcionando cuando se hace zoom grande.\r\nEjemplo:\r\n Una persona intenta llenar un formulario solo con el teclado. Si no logra llegar al botón “Enviar” porque no está bien programado, se detecta un problema de accesibilidad.\r\n3. Comparación con normas o buenas prácticas\r\n•	Se valida que el software cumpla ciertos estándares internacionales que explican qué es un diseño accesible.\r\n•	Por ejemplo:\r\no	Que los enlaces tengan nombres claros (“Ver resultados de exámenes” en vez de “Haz clic aquí”).\r\no	Que haya subtítulos en videos.\r\no	Que el contenido no dependa solo de colores (ejemplo: “los campos en rojo están mal” es un error, porque alguien daltónico no verá la diferencia).\r\nSu importancia:\r\nLa prueba de accesibilidad es importante porque garantiza la inclusión social al permitir que las personas con discapacidad utilicen sistemas y aplicaciones en igualdad de condiciones. También mejora la experiencia de uso en general, ya que un software accesible resulta más claro y sencillo para todos los usuarios. Además, ayuda a cumplir con normativas legales que exigen accesibilidad en servicios digitales y refleja un compromiso ético y social por parte de las organizaciones, lo cual fortalece su reputación y confianza frente a la comunidad.\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiposprueba`
--

CREATE TABLE `tiposprueba` (
  `id` int(11) NOT NULL,
  `concepto` varchar(100) NOT NULL,
  `definicion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tiposprueba`
--

INSERT INTO `tiposprueba` (`id`, `concepto`, `definicion`) VALUES
(1, 'Pruebas Funcionales', 'Son una forma de determinar si el software o una aplicación funcionan como se espera. Las pruebas funcionales no se ocupan de cómo se produce el procesamiento, sino de si éste ofrece los resultados correctos o tiene algún fallo.'),
(2, 'Pruebas No Funcionales', 'Son un tipo de pruebas de software que evalúan cómo se comporta un sistema más allá de sus funciones básicas. A diferencia de las pruebas funcionales que verifican qué hace el sistema, estas se enfocan en atributos de calidad como el rendimiento, la seguridad, la escalabilidad, la usabilidad, la compatibilidad y la confiabilidad.'),
(3, 'Pruebas de Estructura o de Caja Blanca', 'Son un tipo de verificación del software en la que se analiza directamente el código fuente, su lógica interna y la forma en que están construidas las estructuras de control. A diferencia de las pruebas de caja negra, aquí se busca comprobar el \"cómo funciona\" el programa por dentro, diseñando casos de prueba que permitan recorrer sentencias, condiciones, bucles y rutas lógicas del sistema para medir su cobertura y asegurar que todas se ejecuten al menos una vez.'),
(4, 'Pruebas Relacionadas con el Cambio', 'Definición pendiente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `nivelesprueba`
--
ALTER TABLE `nivelesprueba`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pruebascambio`
--
ALTER TABLE `pruebascambio`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pruebasintegracion`
--
ALTER TABLE `pruebasintegracion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pruebasnofuncionales`
--
ALTER TABLE `pruebasnofuncionales`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pruebasrendimiento`
--
ALTER TABLE `pruebasrendimiento`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pruebasusabilidad`
--
ALTER TABLE `pruebasusabilidad`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tiposprueba`
--
ALTER TABLE `tiposprueba`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `nivelesprueba`
--
ALTER TABLE `nivelesprueba`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `pruebascambio`
--
ALTER TABLE `pruebascambio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pruebasintegracion`
--
ALTER TABLE `pruebasintegracion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pruebasnofuncionales`
--
ALTER TABLE `pruebasnofuncionales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `pruebasrendimiento`
--
ALTER TABLE `pruebasrendimiento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `pruebasusabilidad`
--
ALTER TABLE `pruebasusabilidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tiposprueba`
--
ALTER TABLE `tiposprueba`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
