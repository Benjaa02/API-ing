<?php
include('conexion.php');
if (!isset($_GET['tabla'])) exit;
$tabla = $_GET['tabla'];
$result = $conn->query("SELECT * FROM $tabla ORDER BY id ASC");
if (!$result || $result->num_rows === 0) {
    echo "<p class='empty'>Sin registros disponibles.</p>";
    exit;
}
echo "<table><thead><tr><th>ID</th><th>Concepto</th><th>Definición</th></tr></thead><tbody>";
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td class='concepto'>{$row['concepto']}</td><td>{$row['definicion']}</td></tr>";
}
echo "</tbody></table>";
?>
